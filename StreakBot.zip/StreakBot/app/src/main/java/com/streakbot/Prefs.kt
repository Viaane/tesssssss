package com.streakbot

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun p(c: Context) = c.getSharedPreferences("streakbot", Context.MODE_PRIVATE)
    private fun lines(s: String) = s.lines().map { it.trim() }.filter { it.isNotEmpty() }

    fun friendsRaw(c: Context) = p(c).getString("friends", "") ?: ""
    fun messagesRaw(c: Context) = p(c).getString("messages", "🔥") ?: "🔥"
    fun friends(c: Context) = lines(friendsRaw(c))
    fun messages(c: Context) = lines(messagesRaw(c)).ifEmpty { listOf("🔥") }
    fun hour(c: Context) = p(c).getInt("hour", 8)
    fun minute(c: Context) = p(c).getInt("minute", 0)
    fun jitter(c: Context) = p(c).getInt("jitter", 10)
    fun enabled(c: Context) = p(c).getBoolean("enabled", false)

    fun save(c: Context, friends: String, messages: String, hour: Int, minute: Int, jitter: Int, enabled: Boolean) {
        p(c).edit()
            .putString("friends", friends).putString("messages", messages)
            .putInt("hour", hour).putInt("minute", minute)
            .putInt("jitter", jitter).putBoolean("enabled", enabled)
            .apply()
    }

    fun log(c: Context, line: String) {
        val t = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
        val old = logText(c).lines().filter { it.isNotBlank() }
        p(c).edit().putString("log", (listOf("$t  $line") + old).take(40).joinToString("\n")).apply()
    }

    fun logText(c: Context) = p(c).getString("log", "") ?: ""
}
