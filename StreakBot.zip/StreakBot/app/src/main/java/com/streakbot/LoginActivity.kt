package com.streakbot

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/** Login TikTok sekali di sini. Sesi (cookie) dipakai ulang oleh WebView tersembunyi. */
class LoginActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val done = Button(this).apply {
            text = "Selesai login"
            setOnClickListener {
                CookieManager.getInstance().flush()
                Toast.makeText(this@LoginActivity, "Sesi disimpan", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.userAgentString = Prefs.DESKTOP_UA
            webViewClient = WebViewClient()
            loadUrl("https://www.tiktok.com/login")
        }
        root.addView(done)
        root.addView(wv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
