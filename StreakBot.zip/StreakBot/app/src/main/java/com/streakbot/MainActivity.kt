package com.streakbot

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var friends: EditText
    private lateinit var messages: EditText
    private lateinit var jitter: EditText
    private lateinit var enabled: Switch
    private lateinit var timeBtn: Button
    private lateinit var logView: TextView
    private var hour = 8
    private var minute = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fmt() = "%02d:%02d".format(hour, minute)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        hour = Prefs.hour(this); minute = Prefs.minute(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTypeface(null, Typeface.BOLD); setPadding(0, dp(14), 0, dp(4))
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }

        root.addView(btn("1. Login TikTok (sekali saja)") {
            startActivity(Intent(this, LoginActivity::class.java))
        })

        root.addView(label("Teman streak (satu per baris, sesuai nama di inbox)"))
        friends = EditText(this).apply {
            setText(Prefs.friendsRaw(this@MainActivity)); minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(friends)

        root.addView(label("Template pesan (satu per baris, dipilih acak)"))
        messages = EditText(this).apply {
            setText(Prefs.messagesRaw(this@MainActivity)); minLines = 2
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(messages)

        root.addView(label("Jam kirim"))
        timeBtn = btn(fmt()) {
            TimePickerDialog(this, { _, h, m -> hour = h; minute = m; timeBtn.text = fmt() }, hour, minute, true).show()
        }
        root.addView(timeBtn)

        root.addView(label("Jeda acak ± menit"))
        jitter = EditText(this).apply {
            setText(Prefs.jitter(this@MainActivity).toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        root.addView(jitter)

        enabled = Switch(this).apply {
            text = "Aktifkan auto streak harian"; isChecked = Prefs.enabled(this@MainActivity)
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(enabled)

        root.addView(btn("Simpan & jadwalkan") {
            val j = jitter.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 10
            Prefs.save(this, friends.text.toString(), messages.text.toString(), hour, minute, j, enabled.isChecked)
            if (enabled.isChecked) Scheduler.schedule(this, false) else Scheduler.cancel(this)
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
            refreshLog()
        })
        root.addView(btn("Kirim sekarang (tes)") {
            Prefs.save(this, friends.text.toString(), messages.text.toString(), hour, minute,
                jitter.text.toString().toIntOrNull() ?: 10, enabled.isChecked)
            ContextCompat.startForegroundService(this, Intent(this, StreakService::class.java))
            Toast.makeText(this, "Berjalan di latar belakang…", Toast.LENGTH_SHORT).show()
        })
        root.addView(btn("Izinkan tanpa optimasi baterai") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(label("Log"))
        logView = TextView(this).apply { textSize = 12f }
        root.addView(logView)

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    override fun onResume() { super.onResume(); refreshLog() }

    private fun refreshLog() {
        logView.text = Prefs.logText(this).ifEmpty { "(belum ada log)" }
    }
}
