package com.streakbot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar
import kotlin.random.Random

object Scheduler {
    private fun pi(c: Context) = PendingIntent.getBroadcast(
        c, 1, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(c: Context, forceTomorrow: Boolean) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.hour(c))
            set(Calendar.MINUTE, Prefs.minute(c))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (forceTomorrow || cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        val j = Prefs.jitter(c)
        if (j > 0) cal.add(Calendar.MINUTE, Random.nextInt(-j, j + 1))
        val at = maxOf(cal.timeInMillis, now + 10_000)

        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c))
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c))
        Prefs.log(c, "Jadwal berikutnya: ${java.text.SimpleDateFormat("dd/MM HH:mm").format(at)}")
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c))
    }
}
